import { Component, OnDestroy, inject } from '@angular/core';
import { Subscription } from 'rxjs';
import { ApicallService } from '../shared/apicall.service';
import { Country } from '../shared/country';

@Component({ standalone: false, selector: 'Search', templateUrl: './search.component.html' })
export class SearchComponent implements OnDestroy {
  private api = inject(ApicallService);
  private request?: Subscription;
  name = '';
  countries: Country[] = [];
  message = '';

  searchCapital(): void {
    this.request?.unsubscribe();
    this.countries = [];
    if (!this.name.trim()) {
      this.message = 'Entre une capitale.';
      return;
    }
    this.message = 'Recherche en cours…';
    this.request = this.api.searchCountryByName(this.name).subscribe({
      next: rows => {
        this.countries = rows;
        this.message = rows.length ? '' : 'Aucun résultat.';
      },
      error: error => {
        this.message = error.status === 404 ? 'Capitale introuvable.' : 'Service indisponible. Réessaie plus tard.';
      },
    });
  }

  ngOnDestroy(): void { this.request?.unsubscribe(); }
}