import { Component, inject, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NativeScriptCommonModule, NativeScriptFormsModule } from '@nativescript/angular';

@Component({
  selector: 'Home',
  imports: [NativeScriptCommonModule, NativeScriptFormsModule, ReactiveFormsModule],
  schemas: [NO_ERRORS_SCHEMA],
  templateUrl: './home.component.html',
})
export class HomeComponent {
  signUpForm = inject(FormBuilder).nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    username: ['', [Validators.required, Validators.pattern(/\S/)]],
  });
  message = '';

  onButtonTap(): void {
    if (this.signUpForm.invalid) {
      this.message = 'Entre un courriel valide et un nom d’utilisateur.';
      return;
    }
    const { email, username } = this.signUpForm.getRawValue();
    console.log(JSON.stringify({ email: email.trim(), username: username.trim() }));
    this.message = 'Inscription affichée dans la console.';
  }
}