import { Component, OnInit } from '@angular/core'
import { RadSideDrawer } from 'nativescript-ui-sidedrawer'
import { Application, View } from '@nativescript/core'

@Component({
  standalone: false,
  selector: 'Browse',
  templateUrl: './browse.component.html',
})
export class BrowseComponent implements OnInit {
  busy = false;

  async animate(view: View): Promise<void> {
    if (this.busy) return;
    this.busy = true;
    const duration = 300;
    try {
      await view.animate({ opacity: 0, duration });
      await view.animate({ opacity: 1, duration });
      await view.animate({ translate: { x: 150, y: 150 }, duration });
      await view.animate({ translate: { x: 0, y: 0 }, duration });
      await view.animate({ scale: { x: 2, y: 2 }, duration });
      await view.animate({ scale: { x: 1, y: 1 }, duration });
      await view.animate({ rotate: 180, duration });
      await view.animate({ rotate: 0, duration });
    } finally {
      view.opacity = 1;
      view.translateX = view.translateY = view.rotate = 0;
      view.scaleX = view.scaleY = 1;
      this.busy = false;
    }
  }

  constructor() {
    // Use the component constructor to inject providers.
  }

  ngOnInit(): void {
    // Init your component properties here.
  }

  onDrawerButtonTap(): void {
    const sideDrawer = Application.getRootView() as RadSideDrawer
    sideDrawer.showDrawer()
  }
}
