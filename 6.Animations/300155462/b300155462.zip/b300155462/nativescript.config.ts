import type { NativeScriptConfig } from '@nativescript/core';

export default {
  id: 'ca.boreal.zakaria.animations',
  appPath: 'src',
  appResourcesPath: 'App_Resources',
} as NativeScriptConfig;
